<template>
  <div>
    <table class="table table-bordered">
      <thead>
        <!-- 테이블 제목-->
        <tr class="table-warning">
          <!-- 제목 : 굵은글씨 -->
          <th scope="col">번호(eno)</th>
          <th scope="col">이름(ename)</th>
          <th scope="col">직업(job)</th>
          <th scope="col">관리(manager)</th>
          <th scope="col">연봉(salary)</th>
        </tr>
      </thead>
      <!-- 테이블 본문 -->
      <tbody v-for="(data,index) in emp" :key="index">
        <tr>
          <td>{{ data.eno }}</td>
          <td>{{ data.ename }}</td>
          <td>{{ data.job }}</td>
          <td>{{ data.manager }}</td>
          <td>{{ data.salary }}</td>
        </tr>
        <!-- <tr>
          <th scope="row">2</th>
          <td>Jacob</td>
          <td>Thornton</td>
          <td>@fat</td>
        </tr>
        <tr>
          <th scope="row">3</th>
          <td colspan="2">Larry the Bird</td>
          <td>@twitter</td>
        </tr> -->
      </tbody>
    </table>
  </div>
</template>
<script>
import EmpService from "../services/EmpService";

export default {
  data() {
    return {
      emp: [],
    };
  },
  methods: {
    async retrieveEmp() {
      try {
        let response = await EmpService.getAll(); // 프라미스 함수
        console.log(response.data);
        this.emp = response.data.emp;
      } catch (e) {
        console.log(e);
      }
    },
  },
  mounted() {
    this.retrieveEmp();
  }
};
</script>
<style>
</style>