import http from "../utils/HttpCommon"

class EmpService {
    getAll() {
        return http.get("/emp.json");
    }
}

export default new EmpService();